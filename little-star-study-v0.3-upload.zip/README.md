# 小星星学习屋 (Little Star Study)

适合安卓平板的离线语文/英语学习 APP。家长从系统文件选择器导入 MP4、PDF、JPG/PNG、DOC/DOCX。Word 文档由外部兼容阅读器打开。

## 安卓手机：最少操作上传并构建

1. 在 GitHub 仓库页面点击 **Code > Codespaces > Create codespace on main**。
2. 在 Codespaces 左侧文件区上传 `little-star-study-v0.3-upload.zip` 到仓库根目录（与 README.md 同级）。
3. 在 Codespaces 终端复制粘贴下列命令：

```bash
unzip -o little-star-study-v0.3-upload.zip && rm little-star-study-v0.3-upload.zip && git add . && git commit -m "Add Little Star Android app" && git push origin main
```

4. 回到 GitHub 仓库的 **Actions** 标签，选择 **Build Android APK**。推送到 main 会自动触发；也可点击 Run workflow。
5. 构建成功后打开对应运行记录，在 **Artifacts** 下载 `LittleStarStudy-debug-apk`，解压获得 `app-debug.apk`。

如果 Codespaces 上传入口不可用，尝试 Chrome 桌面版网站；不要将 ZIP 直接上传到普通 GitHub 仓库后期待自动构建。

## 项目结构

- `app/src/main/java/com/littlestar/study/MainActivity.kt`：首页、课程、家长导入和阅读。
- `.github/workflows/android-apk.yml`：云端 APK 构建。
- `app/build.gradle.kts`：Android 构建配置。

## 重要说明

- 本项目目前是 MVP 源码，**尚未完成 Android 云端编译或真机验证**。请以 Actions 实际结果为准。
- 公开仓库仅放源代码，**不要上传孩子个人信息、老师教材、视频、API 密钥或签名私钥**。
- 目前家长验证是简单算术题，不能视为可靠的安全保护；正式给儿童长期使用前需要改进。
- 安卓 8.0 及以上（minSdk 26）；构建输出是 debug APK，不是应用商店发布包。
- 仓库推送后如果 Actions 未运行，请检查仓库 Settings > Actions 的运行权限。
